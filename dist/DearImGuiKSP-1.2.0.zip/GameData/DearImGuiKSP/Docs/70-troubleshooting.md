# Troubleshooting

Symptom-first fixes for the failure modes a modder or player is likely to hit. For API usage questions, start with [API Fundamentals](10-api-fundamentals.md); for install and dependency declaration, [Getting Started](00-getting-started.md).

## Reading the log

Every library log line is written to `KSP.log` (KSP's standard log at the install root) with the `[DearImGuiKSP]` prefix. Warn/error/info lines are always on; additional `[DearImGuiKSP] [debug] ...` diagnostics require `verboseLogging = true` in `GameData/DearImGuiKSP/settings.cfg`. Players can also flip that switch live in the "DearImGui-KSP Settings" window (the library's own toolbar button). When reporting a bug, attach the log with verbose logging on.

## "DearImGui-KSP — Startup Failed" popup at the main menu

The library hit an unrecoverable startup failure. This is **session-permanent by design**: the library self-disables, shows exactly one plain-language popup, and puts the technical detail in the log. Restarting KSP retries from scratch; there is no in-session recovery. The popup body tells you which of the four failure kinds it was, and the matching log line just above it has the specifics:

| Popup body says | Failure kind | Log shows | Fix |
|---|---|---|---|
| "native component is missing or corrupt" | `NativeComponent` | LoadLibrary/Win32 errors, missing exports, context/texture init codes | Reinstall the library package intact: `DearImGuiKSP/Plugins/DearImGuiKSP.dll` and `DearImGuiKSP/PluginData/DearImGuiKSPNative.dll` must both be present |
| "components are from different versions" | `VersionMismatch` | handshake line (below) | Reinstall **both** DLLs from one release — see next section |
| "this graphics API is not supported" | `GraphicsApi` | the detected `GraphicsDeviceType` | Run KSP on Direct3D 11 (default) or OpenGL Core (`-force-glcore`); other graphics APIs are not supported |
| (same as native component) | `RenderHook` | "GetRenderEventFunc returned a null pointer" | Treat as native component: reinstall; report if it persists |

Your mod is unaffected code-wise: `DearImGuiKSP.IsAvailable` is false, your `Register` call is ignored with a warning, and any IMGUI fallback you built (see [Migration](60-migration-from-imgui.md)) takes over.

## Version mismatch between the DLLs

Managed and native DLLs always release together in lockstep — never mix DLLs
from different releases. A startup version handshake enforces this
(currently expected version **7** on the managed side). A stale or partially
copied native DLL fails the handshake before anything else runs, with this
log line:

```
[DearImGuiKSP] Native/managed handshake mismatch: expected version 7, DearImGuiKSPNative reported <n>.
```

Fix: copy both DLLs from the same release zip. `DearImGuiKSPNative.dll` belongs in `GameData/DearImGuiKSP/PluginData/` (not next to the managed DLL); a missing native DLL is the `NativeComponent` failure instead. Consumers: declaring `KSPAssemblyDependencyEqualMajor("DearImGuiKSP", x, y)` keeps KSP's loader from mixing a different managed major with your build (see [Getting Started](00-getting-started.md)).

## Font fallback

If the configured font cannot be found or read at startup, the library falls back to the embedded default font (ProggyClean) — a degraded look, not a failure — and logs exactly one line:

```
[DearImGuiKSP] Font '<name>' not found or unreadable; using embedded default font.
```

Fix: place the TTF under `GameData/DearImGuiKSP/Fonts/` and set `font = <filename>` (or `font = IBMPlexSans`, the shipped default; `font = ProggyClean` selects the embedded font deliberately) in `settings.cfg`. Related: an unknown `theme` value falls back to `ksp` with `Unknown theme '<name>'; using 'ksp'.` — valid theme names are `ksp` and `dark`.

## "My widget calls do nothing"

Three causes, in order of likelihood:

1. **The calls run outside a registered callback.** Widget calls are only valid inside the `Action` you passed to `DearImGuiKSP.Register`; from anywhere else they silently no-op (never throw). If your drawing code is invoked from `Update`, a timer, or an event handler, move it into the registered callback.
2. **The library is not available.** When `IsAvailable` is false (startup failure above, or the game is still loading), every call no-ops. Check `IsAvailable` before registering and don't draw from elsewhere.
3. **The UI is suspended.** During F2-hide and loading screens the frame loop stops — no callbacks run, nothing renders. This is a pause, not a failure; callbacks resume automatically. Keep your state in fields so the next callback reconstructs the window.

Also check your scope guard: content after `if (!window.Visible) return;` is skipped on frames the window is collapsed or clipped — that is normal, not a malfunction.

## "Register ignored" warnings

```
[DearImGuiKSP] Register('<id>') ignored: DearImGui-KSP is not available.
[DearImGuiKSP] Register('<id>') ignored: id already registered.
```

The first is cause 1/2 above. The second means a consumer with that id is already registered — ids must be unique per session. Typical cause: registering from both `Start` and a scene-change path without unregistering, or two instances of your addon. Guard with `Unregister` in `OnDestroy` before re-registering, or make registration idempotent. `Unregister` on an unknown id simply returns false.

## "Consumer '<id>' threw an exception ... auto-disabled"

Your callback threw. The fault barrier catches it, logs it, and skips only your consumer for that frame; after **5 consecutive throwing frames** your consumer is auto-disabled for the session (other consumers are unaffected). The log line names your consumer id and carries the exception. Note the useful property: because `using` scopes dispose during exception unwinding, an exception thrown inside a window/style scope still leaves the ImGui stack symmetric — you will not corrupt other consumers, just get yourself disabled.

Recovery does not require a game restart: auto-disable flips a per-registration
flag, so `Unregister(id)` followed by `Register(id, callback)` re-registers the
consumer with a clean slate and it runs again from the next frame. Do that only
after you have fixed the throwing path, or the consumer burns through the same
five frames and disables itself again.

## Tween warnings: "ignored" and "setter threw"

```
[DearImGuiKSP] Tween.To(...) ignored: DearImGui-KSP is not available.
[DearImGuiKSP] Tween.To(...) baseline setter threw; the tween was not started. Exception: ...
[DearImGuiKSP] Tween setter threw; the tween has been stopped. Exception: ...
```

All three mean the tween you started is **not running**, but none is a library
failure:

- **"ignored: not available"** — you called `Tween.To` while the library was
  unavailable (startup failure, or before it finished loading). The returned
  handle is inert (`IsPlaying` false, `Cancel` a no-op); nothing threw. Gate on
  `IsAvailable` if the warning is noise to you.
- **"baseline setter threw"** — your setter threw on the immediate `set(from)`
  call. The exception is contained, logged, and the tween is refused (inert
  handle); other tweens and consumers are unaffected. Fix the setter and start
  the tween again.
- **"setter threw; the tween has been stopped"** — your setter threw on a
  per-frame tick. Only that tween is stopped (logged once, no rethrow storm);
  every other tween and consumer keeps running.

## Empty-ID assert: "Cannot have an empty ID at the root of a window"

Any ImGui item needs a non-empty ID; at window root an empty label resolves to the window's own ID and trips an ItemAdd assert. The library's own spinner bindings hit this during development and now ship per-type invisible default IDs — the lesson generalizes to you:

- "Invisible ID" means a `##` prefix (`"##my_section"`), never an empty string.
- Widget labels double as IDs; rename a label and you get a new identity (lost state such as scroll positions is expected).
- Place two spinners of the **same type** in one window and you must pass distinct `id` values to `Spinner(...)`, which exists for exactly this.

Build nuance: a **debug** native build (`build.bat`) shows the assert dialog when this fires; the shipped **release** DLL (`build_release.bat`, `/DNDEBUG`) compiles asserts out, so the same bug degrades silently into wrong identity/behavior instead of a clear stop. Develop against the debug build so you see asserts; never treat release silence as correctness.

## Very large draw lists

There is no 65,535-vertex ceiling per draw list here. ImGui keeps 16-bit
indices, but the shipped D3D11 backend sets `RendererHasVtxOffset`, so ImGui
chunks oversized lists across multiple draw commands with vertex offsets and
the effective limit is never reached in practice. (Keeping 16-bit indices was
a deliberate choice — recorded as decision D32 — not a hard ceiling you can
hit.)

Density still costs real time, though: every submitted vertex is rebuilt every
frame, so a single window stuffed with very dense content is a performance
problem before it is any kind of limit. For context, a 10,000-point line is
about 20k vertices — cheap. Remedies, in order of preference:

- **Plot a rolling window instead of full history** (see [Plotting](40-plotting.md)) — fewer points, constant cost.
- **Split dense content across windows or scroll regions** — smaller lists, and separate windows/regions get their own.
- Downsample deliberately (e.g. plot every Nth sample) rather than rendering data no one can read at that density anyway.

## Performance

- **Plots cost per point.** Per-frame plot cost scales with submitted point count; the demo's full-buffer telemetry graphs grew to ~7 ms/frame late in flight before the rolling-window fix (1200 samples, ~20 s at 60 Hz, plotted per cell). Keep your plotted windows bounded; auto-fit is cheap at those sizes.
- **Hover readouts allocate on hover.** A `string.Format` readout under a hovered plot is the demo's one sanctioned per-frame allocation — user-driven, bounded to one hovered cell. Do not format strings on the unhovered path; pass label literals.
- **The benchmark window is the regression instrument.** The demo mod ships a naive-vs-virtualized 1000-item benchmark window (`BenchmarkUI`) used as the standing performance gate. If you suspect your UI is slow, reproduce with it and compare; the library targets no measurable FPS impact with a few typical windows and under 1 ms managed frame cost.
- **Window count and scopes.** A few windows from one registered callback is the intended pattern (the demo draws three from one registration). Scopes are structs — `using` them costs nothing; do not pool or cache them across frames.

## Known limitations (honest list)

- **Intermittent whole-UI flicker** (known open issue): rarely the entire library UI flickers or disappears for a frame or two — reported worse in flight and especially under time warp; no reliable repro yet. Under active investigation; when it is understood this list will be updated.
- **Spinner tints are partially upstream-inherent**: `SpinnerType.RainbowMix` derives its hue from the tint's saturation — with the default white tint it renders grey and never cycles; pass a saturated `Color` as the tint to get the rainbow. `SpinnerType.Atom` hardcodes its electron dots to red/green/blue; the tint colors only the ellipses. Both are vendor behavior, not binding bugs; spinner rendering is under review before release.
- **OpenGL Core only**: OpenGL works via `-force-glcore`; legacy OpenGL and OpenGL ES are not supported, and graphics mods that fail under GL themselves (Cinematic Shaders, Cinematic Recorder) remain unusable there regardless of this library.
- **Text input modifiers**: navigation/edit keys and Ctrl only — Ctrl+A works; Shift+Arrow / Shift+Home/End selection does not.
- **No public horizontal layout helper** (SameLine et al.): layout is vertical-first for now; a public layout surface is a possible later addition. Use `SetCursorY`/`Dummy` for spacing (see [Migration](60-migration-from-imgui.md)).
- **Library-owned settings only**: the library persists its own `settings.cfg` (and deliberately writes no imgui.ini); per-consumer window positions and state are yours to keep.
- **Docked windows cannot leave the game window** (ISSUES #011): multi-viewports are deliberately disabled — an embedded KSP plugin cannot sanely own OS platform windows — so a docked window is always clipped to the game window. Undock it if you need to drag it to the edge.
- **Dock layouts are not persisted** (ISSUES #011): there is no imgui.ini by design (D7), so nothing remembers how windows were arranged — neither programmatic layouts nor the player's manual rearrangements survive a session restart. Consumers reapply their intended layout each session with the DockBuilder calls (one-time, guarded); see the recipe in [Widgets](20-widgets.md#window-docking).
- **`clampWindowsToViewport` skips docked windows** (ISSUES #011): a docked window's position is owned by its dock node, not by the window, so the screen-edge clamping that applies to floating windows does not touch it. A dock layout wider/taller than the game window can therefore place docked content partially outside the viewport until the player resizes the splitters; the library leaves that to the dock node rather than fighting it.
- **Docking off mid-session undocks everything** (ISSUES #011): the player toggle applies live — turning docking off undocks all windows immediately, and turning it back on does not restore the previous arrangement. Consumer one-time layouts reapply on their own guard; manual rearrangements are lost.

## Next

- [Plotting](40-plotting.md), [Animation](50-animation.md), [Migration](60-migration-from-imgui.md) for the feature docs.
- [Getting Started](00-getting-started.md) for install/dependency basics.
